System.register("chunks:///_virtual/objects3",[],(function(){"use strict";return{execute:function(){}}}));
