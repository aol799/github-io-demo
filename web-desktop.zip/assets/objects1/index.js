System.register("chunks:///_virtual/objects1",[],(function(){"use strict";return{execute:function(){}}}));
