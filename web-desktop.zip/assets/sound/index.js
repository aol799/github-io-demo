System.register("chunks:///_virtual/sound",[],(function(){"use strict";return{execute:function(){}}}));
