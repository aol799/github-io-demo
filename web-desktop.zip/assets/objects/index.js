System.register("chunks:///_virtual/objects",[],(function(){"use strict";return{execute:function(){}}}));
