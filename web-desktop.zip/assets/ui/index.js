System.register("chunks:///_virtual/ui",[],(function(){"use strict";return{execute:function(){}}}));
