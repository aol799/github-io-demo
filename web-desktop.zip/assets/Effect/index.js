System.register("chunks:///_virtual/Effect",[],(function(){"use strict";return{execute:function(){}}}));
