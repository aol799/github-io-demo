System.register("chunks:///_virtual/objects2",[],(function(){"use strict";return{execute:function(){}}}));
