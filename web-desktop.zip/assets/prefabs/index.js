System.register("chunks:///_virtual/prefabs",[],(function(){"use strict";return{execute:function(){}}}));
