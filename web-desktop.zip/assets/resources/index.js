System.register("chunks:///_virtual/resources",[],(function(){"use strict";return{execute:function(){}}}));
