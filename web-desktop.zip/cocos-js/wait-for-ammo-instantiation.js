System.register(["./instantiated-f4ec5af0.js"],(function(t){"use strict";return{setters:[function(e){t("default",e.hM)}],execute:function(){}}}));
