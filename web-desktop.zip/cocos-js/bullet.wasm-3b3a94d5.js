System.register([],(function(e,t){"use strict";return{execute:function(){e("default",new URL("assets/bullet.wasm-9d17e9bf.wasm",t.meta.url).href)}}}));
